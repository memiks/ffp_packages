// -*- c++ -*-
/* Do not edit! -- generated file */
#include <sigc++/adaptors/lambda/select.h>

namespace sigc {

const lambda<internal::lambda_select1> _1;
const lambda<internal::lambda_select2> _2;
const lambda<internal::lambda_select3> _3;
const lambda<internal::lambda_select4> _4;
const lambda<internal::lambda_select5> _5;
const lambda<internal::lambda_select6> _6;
const lambda<internal::lambda_select7> _7;

} /* namespace sigc */
