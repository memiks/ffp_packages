#!/usr/bin/env ruby
#
# Put description here
#
# 
# 
# 
#

require 'swig_assert'

require 'arrays_global'

Arrays_global.array_i = Arrays_global.array_const_i

